<!DOCTYPE html>
<html>
<head>

</head>
<body>
	 <footer style="background-color: #4e4747;padding: 10vw";>
    <p style="color: white; font-weight: bold;
    font-size: 2vw;" class="pull-right"><a href="#">Back to top</a></p>
    <p style="color: white;    font-weight: bold;font-size: 2vw;text-shadow: aqua;text-align: center;color: white;  " >To bulid in each student a strong character and will power to excel globality</p>

  </div>
		
</footer>
</body>
</html>
