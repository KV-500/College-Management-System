<!DOCTYPE html>
<html>
<head>
<title>Table with database</title>
<style>
table {
border-collapse: collapse;
width: 50%;
color: #588c7e;
font-family: monospace;
font-size: 20px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
<table>
<tr>
<th>name</th>
<th>qulification</th>
<th>age</th>
<th>job</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "bridavan");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT  name,qulification,age,job FROM management";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["name"] . "</td><td>"
. $row["qulification"]. "</td><td>" . $row["age"] ."</td><td>"
. $row["job"]. "</td><td><a href=delman.php?name=".$row['name'].">Delete</a></td></tr>" ;

}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

<?php
$conn = mysqli_connect("localhost", "root", "", "bridavan");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "DELETE FROM management WHERE name='$_GET[name]'";

if(mysqli_query($conn,$sql))
   header("delman.php");
else
   echo "Not deleted";

?>
</table>
<a> </a>
</body>
</html>