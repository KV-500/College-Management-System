<?php
   'dbh.inc.php';
	
	$act_id = $POST['ACT_ID'];
	$act_name = $POST['ACT_NAME'];
	$act_gender = $POST['ACT_GENDER'];
    $sql = "INSERTnINTO ACTOR (ACT_ID, ACT_NAME,ACT_GENDER) VALUES ('001', 'keerthi', 'm');";
	mysqli_query($conn,$sql);
	
	header("Location:../actor.php?signup=success");