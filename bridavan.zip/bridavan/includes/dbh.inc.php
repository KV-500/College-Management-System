<?php>
$dbServername = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "moviedb";

$conn = mysqli_connect($dbServername, $dbusername, $dbpassword, $dbname);