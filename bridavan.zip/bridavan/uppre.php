<!DOCTYPE html>

<html>
<head>
  <header>
    <h1>STUDENT</h1>
<title>Form site</title>
</head>
<body>
<form method="post" action="upstu.php">
STUDENTID : <input type="text" name="studentid"><br><br>
1SEM: <input type="text" name="1sem"><br><br>
2SEM: <input type="text" name="2sem"><br><br>
3SEM: <input type="text" name="3sem"><br><br>
4SEM: <input type="text" name="4sem"><br><br>
5SEM: <input type="text" name="5sem"><br><br>
6SEM: <input type="text" name="6sem"><br><br>
7SEM: <input type="text" name="7sem"><br><br>
8SEM: <input type="text" name="8sem"><br><br>
<input type="submit" value="update"> 
</form>
</body>

<?php
$studentid = filter_input(INPUT_POST,'studentid');
$osem = filter_input(INPUT_POST,'1sem');
$tsem = filter_input(INPUT_POST,'2sem');
$thsem = filter_input(INPUT_POST,'3sem');
$fsem = filter_input(INPUT_POST,'4sem');
$fisem = filter_input(INPUT_POST,'5sem');
$ssem = filter_input(INPUT_POST,'6sem');
$sesem = filter_input(INPUT_POST,'7sem');
$esem = filter_input(INPUT_POST,'8sem');
if (!empty($studentid)){
if (!empty($osem)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "bridavan";
// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else
{
	
	$query = "UPDATE precentage SET studentid= ?,1sem= ?,2sem= ?,3sem= ?,4sem=?,5sem=?,6sem=?,7sem=?,8sem=? WHERE studentid = ?";
	
	$stmt = $conn->prepare($query);
	$stmt->bind_param('iiiiiiiiii',$studentid,$osem,$tsem,$thsem,$fsem,$fisem,$ssem,$sesem,$esem,$studentid);
	
	if($stmt->execute()) {
	echo"";	
	}
	$stmt->close();
	$conn->close();
}
}
}
?>