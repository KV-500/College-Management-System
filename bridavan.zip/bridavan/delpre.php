<!DOCTYPE html>
<html>
<head>
<title>Table with database</title>
<style>
table {
border-collapse: collapse;
width: 50%;
color: #588c7e;
font-family: monospace;
font-size: 20px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
<table>
<tr>
<th>studentid</th>
<th>1sem</th>
<th>2sem</th>
<th>3sem</th>
<th>4sem</th>
<th>5sem</th>
<th>6sem</th>
<th>7sem</th>
<th>8sem</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "bridavan");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT  studentid,1sem,2sem,3sem,4sem,5sem,6sem,7sem,8sem FROM precentage";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["studentid"] . "</td><td>"
. $row["1sem"]. "</td><td>" . $row["2sem"] ."</td><td>"
. $row["3sem"]. "</td><td>" . $row["4sem"] ."</td><td>" . $row["5sem"] ."</td><td>" . $row["6sem"] ."</td><td>" . $row["7sem"] ."</td><td>" . $row["8sem"] ."</td><td><a href=delpre.php?studentid=".$row['studentid'].">Delete</a></td></tr>" ;

}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

<?php
$conn = mysqli_connect("localhost", "root", "", "bridavan");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "DELETE FROM precentage WHERE studentid='$_GET[studentid]'";

if(mysqli_query($conn,$sql))
   header("delpre.php");
else
   echo "Not deleted";

?>
</table>
<a> </a>
</body>
</html>