<!DOCTYPE html>
<html>
<head>
<title>Table with database</title>
<style>
table {
border-collapse: collapse;
width: 50%;
color: #588c7e;
font-family: monospace;
font-size: 20px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
<table>
<tr>
<th>staffid</th>
<th>staffname</th>
<th>gender</th>
<th>dept</th>
<th>qulification</th>
</tr>
<?php
$conn = mysqli_connect("localhost", "root", "", "bridavan");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT  staffid,staffname,gender,dept,qulification FROM teachstaff";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["staffid"] . "</td><td>"
. $row["staffname"]. "</td><td>" . $row["gender"] ."</td><td>"
. $row["dept"]. "</td><td>"
. $row["qulification"]. "</td><td><a href=deltec.php?staffid=".$row['staffid'].">Delete</a></td></tr>" ;

}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>

<?php
$conn = mysqli_connect("localhost", "root", "", "bridavan");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "DELETE FROM teachstaff WHERE staffid='$_GET[staffid]'";

if(mysqli_query($conn,$sql))
   header("deltec.php");
else
   echo "Not deleted";

?>
</table>
<a> </a>
</body>
</html>