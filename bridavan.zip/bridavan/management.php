<!DOCTYPE html>

<html>
<head>
  <header>
    <h1>STAFF</h1>
<title>Form site</title>
</head>
<body>
<form method="post" action="management.php">
NAME : <input type="text" name="name"><br><br>
QULIFICATION: <input type="text" name="qulification"><br><br>
AGE: <input type="text" name="age"><br><br>
JOB: <input type="text" name="job"><br><br>
<input type="submit" value="Submit">
</form>
</body>

<?php
$name = filter_input(INPUT_POST, 'name');
$qulification = filter_input(INPUT_POST, 'qulification');
$age = filter_input(INPUT_POST, 'age');
$job = filter_input(INPUT_POST, 'job');
if (!empty($name)){
if (!empty($qulification)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "bridavan";
// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO management (name,qulification,age,job)
values ('$name','$qulification','$age','$job')";
if ($conn->query($sql)){
echo "New record is inserted sucessfully";
}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
else{
echo " name should not be empty";
die();
}
}


?>
 