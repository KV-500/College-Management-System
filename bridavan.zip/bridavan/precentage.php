	
<!DOCTYPE html>

<html>
<link rel="stylesheet" type="text/css" href="style2.css">
<head>

<body>
<div class="login-page">
<div class ="form">
<form method="post" action="precentage.php">
StudentID : <input type="text" name="studentid" placeholder="studentid"><br><br>
 <input type="text" name="1sem" placeholder="1sem"><br><br>
 <input type="text" name="2sem" placeholder="2sem"><br><br>
 <input type="text" name="3sem" placeholder="3sem"><br><br>
 <input type="text" name="4sem" placeholder="4sem"><br><br>
 <input type="text" name="5sem" placeholder="5sem"><br><br>
 <input type="text" name="6sem" placeholder="6sem"><br><br>
 <input type="text" name="7sem" placeholder="7sem"><br><br>
 <input type="text" name="8sem" placeholder="8sem"><br><br>
<input type="submit" value="Submit">
</form>
</body>

<?php
$studentid = filter_input(INPUT_POST,'studentid');
$osem = filter_input(INPUT_POST,'1sem');
$tsem = filter_input(INPUT_POST,'2sem');
$thsem = filter_input(INPUT_POST,'3sem');
$fsem = filter_input(INPUT_POST,'4sem');
$fisem = filter_input(INPUT_POST,'5sem');
$ssem = filter_input(INPUT_POST,'6sem');
$sesem = filter_input(INPUT_POST,'7sem');
$esem = filter_input(INPUT_POST,'8sem');
if (!empty($studentid)){
if (!empty($osem)){
$host = "localhost";
$dbusername = "root";
$dbpassword = "";
$dbname = "bridavan";
// Create connection
$conn = new mysqli ($host, $dbusername, $dbpassword, $dbname);
if (mysqli_connect_error()){
die('Connect Error ('. mysqli_connect_errno() .') '
. mysqli_connect_error());
}
else{
$sql = "INSERT INTO precentage (studentid,1sem,2sem,3sem,4sem,5sem,6sem,7sem,8sem)
values ('$studentid','$osem','tsem','$thsem','$fsem','$fisem','$ssem','$sesem','$esem')";
if ($conn->query($sql)){
echo "New record is inserted sucessfully";
}
else{
echo "Error: ". $sql ."
". $conn->error;
}
$conn->close();
}
}
else{
echo "studentid should not be empty";
die();
}
}


?>
 